package com.example.a3ahd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.balysv.materialripple.MaterialRippleLayout;

public class AllContent extends AppCompatActivity {
MaterialRippleLayout mtrabdalla;
    MaterialRippleLayout HebaVar;
    MaterialRippleLayout HodaVar;
    MaterialRippleLayout AhmedBenaaVar;
    MaterialRippleLayout AymanVar;
    MaterialRippleLayout AnotherVideos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_content);


        mtrabdalla =findViewById(R.id.mtrAbdo);

        mtrabdalla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),AbdallahBook.class);
                startActivity(i);
            }
        });



    HebaVar=findViewById(R.id.mtrHeba);

    HebaVar.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent i=new Intent(getApplicationContext(),hebalec.class);
            startActivity(i);
        }
    });


        HodaVar=findViewById(R.id.mtrHoda);

        HodaVar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),MainActivityhodalecs.class);
                startActivity(i);
            }
        });

        AhmedBenaaVar=findViewById(R.id.mtrAhmedBenaa);

        AhmedBenaaVar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),ahmedbenaa.class);
                startActivity(i);
            }
        });


        AymanVar=findViewById(R.id.mtrAyman3bdELrheem);

        AymanVar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),aymanlecs.class);
                startActivity(i);
            }
        });

        AnotherVideos=findViewById(R.id.mtrAnotherVideos);
        AnotherVideos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),AnotherVideos.class);
                startActivity(i);
            }
        });

}

}

package com.example.a3ahd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class AymanWebview extends AppCompatActivity {
    WebView Aymanlecex;


    @Override
    public void  onBackPressed() {
        if (Aymanlecex.canGoBack()) {
            Aymanlecex.goBack();
        } else {
            super.onBackPressed();
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ayman_webview);


        Aymanlecex =(WebView) findViewById(R.id.AymanwebLec1);

        Intent i=getIntent();
        String website1= i.getStringExtra("links4");

        Aymanlecex.setWebViewClient(new WebViewClient());
        Aymanlecex.loadUrl(website1);

        WebSettings webSettings= Aymanlecex.getSettings();
        webSettings.setJavaScriptEnabled(true);
    }
}
package com.example.a3ahd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.balysv.materialripple.MaterialRippleLayout;

public class aymanlecs extends AppCompatActivity {
    MaterialRippleLayout Aymanlec1tov;
    MaterialRippleLayout Aymanlec2tov;
    MaterialRippleLayout Aymanlec3tov;
    MaterialRippleLayout Aymanlec4tov;

    String [] urls =new String[4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aymanlecs);

        Aymanlec1tov=findViewById(R.id.mtrAymanlecs);
        Aymanlec2tov=findViewById(R.id.mtrAymanlec2);
        Aymanlec3tov=findViewById(R.id.mtrAymanlec3);
        Aymanlec4tov=findViewById(R.id.mtrAymanlec4);

        urls[0]="https://youtube.com/playlist?list=PLv-FY0Y1W7Ay2-qtF-rjR_lhouMbOnh_z";
        urls[1]="https://youtube.com/playlist?list=PLb4fKrb8QI0lqKOQIp86FF9npcmvZjBm6";
        urls[2]="https://youtube.com/playlist?list=PLiyp8353pdD6xaLaeM-nI7f-_0KmVUlje";
        urls[3]="https://youtube.com/playlist?list=PLiyp8353pdD4stC6q0673PfjrpBx6rpiv";



        Aymanlec1tov.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),AymanWebview.class);
                i.putExtra("links4",urls[0]);
                startActivity(i);
            }
        });
        Aymanlec2tov.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),AymanWebview.class);
                i.putExtra("links4",urls[1]);
                startActivity(i);
            }
        });


        Aymanlec3tov.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),AymanWebview.class);
                i.putExtra("links4",urls[2]);
                startActivity(i);
            }
        });

        Aymanlec4tov.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),AymanWebview.class);
                i.putExtra("links4",urls[3]);
                startActivity(i);
            }
        });


    }
}
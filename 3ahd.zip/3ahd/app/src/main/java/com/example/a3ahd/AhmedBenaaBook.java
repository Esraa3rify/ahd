package com.example.a3ahd;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class AhmedBenaaBook extends AppCompatActivity {
 PDFView AhmedBook;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ahmed_benaa_book);

        AhmedBook=findViewById(R.id.AhmedPdfView);
        AhmedBook.fromAsset("ahmed.pdf")
                .load()
        ;
    }
}